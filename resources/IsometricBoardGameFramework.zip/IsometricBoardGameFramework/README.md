# IsometricBoardGameFramework
A light work framework for Game Maker Studio 2 to create a 2D Isometric Turn Based Game
